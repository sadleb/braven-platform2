/* Tin Can configuration */

//
// ActivityID that is sent for the statement's object
//
TC_COURSE_ID = "http://CVRBwM4pr955T7w5VaRCUOFE9zfZXe-x_rise"

//
// CourseName for the activity
//
TC_COURSE_NAME = {
  "en-US": "Unlock Your Hustle"
};

//
// CourseDesc for the activity
//
TC_COURSE_DESC = {
  "en-US": "&lt;p&gt;Discover your inner leader.&lt;/p&gt;"
};
